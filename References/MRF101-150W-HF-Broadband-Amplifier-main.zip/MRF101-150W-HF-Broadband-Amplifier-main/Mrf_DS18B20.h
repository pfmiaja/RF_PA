#ifndef Mrf_DS18B20_h
#define Mrf_DS18B20_h

class Mrf_DS18B20
{
  public:
  	Mrf_DS18B20(void);
  	float getTemp(int);
  	
  	
  private:
  
};

#endif